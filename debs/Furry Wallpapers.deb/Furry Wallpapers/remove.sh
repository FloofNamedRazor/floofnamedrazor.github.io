rm -r *.deb
rm -r Packages.bz2
